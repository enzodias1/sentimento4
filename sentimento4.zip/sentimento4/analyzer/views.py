from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from textblob import TextBlob
from .forms import SentimentForm

def cadastro(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        senha = request.POST['senha']
        confirmar_senha = request.POST['confirmar_senha']

        if senha != confirmar_senha:
            return render(request, 'analyzer/cadastro.html', {'erro': 'As senhas não coincidem.'})

        if User.objects.filter(username=username).exists():
            return render(request, 'analyzer/cadastro.html', {'erro': 'Nome de usuário já existe.'})

        user = User.objects.create_user(username=username, email=email, password=senha)
        login(request, user)  
        return redirect('login') 

    return render(request, 'analyzer/cadastro.html')


def login_view(request):
    if request.method == "POST":
        user = authenticate(
            request, username=request.POST["username"], password=request.POST["password"]
        )
        if user:
            login(request, user)
            return redirect("analyze")
        return render(request, "analyzer/login.html", {"error": "Credenciais inválidas"})
    return render(request, "analyzer/login.html")

def logout_view(request):
    logout(request)
    return redirect("login")

@login_required
def analyze_view(request):
    result = None
    if request.method == "POST":
        form = SentimentForm(request.POST)
        if form.is_valid():
            text = form.cleaned_data["text"]
            blob = TextBlob(text)
            polarity = blob.sentiment.polarity
            if polarity > 0:
                sentiment = "Positivo"
            elif polarity < 0:
                sentiment = "Negativo"
            else:
                sentiment = "Neutro"
            result = {"sentiment": sentiment, "score": round(polarity, 2)}
    else:
        form = SentimentForm()
    return render(request, "analyzer/analyze.html", {"form": form, "result": result})

